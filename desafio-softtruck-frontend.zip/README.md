# desafio-softtruck-frontend
Simulador de rastreamento veicular animado com dados GPS (Desafio técnico Softruck)
